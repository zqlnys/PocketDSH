#!/bin/sh
# Runs a spread of shell constructs and reports which survive. M3 claims
# pipelines, redirection and scripts work; this is how that claim is checked.
#
#   tools/m3-sweep.sh /path/to/busybox [tools/rune] [seconds-per-case]
set -u
BUSYBOX=${1:?usage: m3-sweep.sh BUSYBOX [RUNE] [LIMIT]}
RUNE=${2:-./tools/rune}
LIMIT=${3:-40}

# Say what is missing once, rather than reporting every case as "cannot load". The run
# would still fail, but a hundred identical messages bury the one fact that matters.
if [ ! -x "$BUSYBOX" ]; then
    echo "$(basename "$0"): $BUSYBOX not found - the static busybox is required" >&2
    exit 2
fi
if [ ! -x "$RUNE" ]; then
    echo "$(basename "$0"): $RUNE not found - run 'make' in e2/ first" >&2
    exit 2
fi

pass=0
fail=0
noisy=
failed=""

while IFS= read -r cmd; do
    [ -z "$cmd" ] && continue
    # A comment is not a test. Running `sh -c "# ..."` succeeds trivially, which
    # used to inflate the pass count by one for every explanatory line.
    case "$cmd" in \#*) continue ;; esac
    out=$(timeout "$LIMIT" "$RUNE" "$BUSYBOX" sh -c "$cmd" < /dev/null 2>&1)
    status=$?
    if [ "$status" -eq 124 ]; then
        fail=$((fail + 1))
        failed="$failed
  [$cmd] timed out - likely a scheduling deadlock"
        continue
    fi
    if echo "$out" | grep -qE "not found|can't open|No such file|not implemented|Function not"; then
        noisy="$noisy
  [$cmd] $(echo "$out" | grep -oE "not found|can't open|No such file|not implemented|Function not" | head -1)"
    fi
    if echo "$out" | grep -q "FAULT\|instruction cap\|cannot load"; then
        fail=$((fail + 1))
        failed="$failed
  [$cmd] $(echo "$out" | tail -1 | cut -c1-90)"
    else
        pass=$((pass + 1))
    fi
done <<'EOF'
# Arguments and variable values longer than the old 63/95-byte buffers. These
# silently resolved to the wrong thing before, so they are worth keeping.
awk 'BEGIN{count=0; items[1]=1; for(k in items) if(items[k]) {count=items[k]; pick=1}; print count}'
LONGVAR=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa; echo ${#LONGVAR}
# Above roughly six thousand lines the consumer used to finish a read before the
# producer had written the rest, which only a wide enough time slice papered over.
# This case would have caught it.
seq 6000 | wc -l
seq 3000 | grep -c 1
printf 'c\na\nb\na\n' > /tmp/m3p; sort /tmp/m3p | uniq -c
printf 'c\na\nb\na\n' > /tmp/m3p; sort /tmp/m3p | uniq -d
printf 'c\na\nb\na\n' > /tmp/m3p; cat /tmp/m3p | grep -c a
printf 'c\na\nb\na\n' > /tmp/m3p; cat /tmp/m3p | head -2 | tail -1
seq 10 | paste -sd-
seq 10 | awk '{s+=$1} END{print s/NR}'
seq 5 | xargs echo
echo 'a b c' | tr ' ' '\n' | wc -l
seq 6 | sed -n '2,4p' | wc -l
printf 'c\na\nb\na\n' > /tmp/m3p; cat /tmp/m3p | sort -u | wc -l
yes | head -100 | wc -l
seq 3 | cat; echo $?
(exit 3); echo $?
sh -c "exit 3"; echo $?
/bin/false; echo $?
true; echo $?
trap "echo bye" EXIT; echo hi
printf 'p q\nr s\n' > /tmp/m3r; while read x y; do echo $y-$x; done < /tmp/m3r
echo a b | while read x y; do echo $y $x; done
echo a | read x; echo got $x
printf 'a b\nc d\n' > /tmp/m3r; awk '{print $2, $1}' /tmp/m3r
echo a | cat
echo a | cat | cat
printf x\n | wc -l
echo hi > /tmp/m3a; cat /tmp/m3a
echo a > /tmp/m3b; echo b >> /tmp/m3b; wc -l < /tmp/m3b
X=5; echo $X
X=5; Y=6; echo $((X+Y))
echo $(echo nested)
X=$(echo v); echo $X
echo `echo bt`
echo $((2*3))
false || echo fallback
true && echo yes
if true; then echo t; fi
if false; then echo t; else echo f; fi
for i in 1 2 3; do echo $i; done
i=0; while [ $i -lt 3 ]; do echo $i; i=$((i+1)); done
echo a; echo $?
false; echo $?
case x in x) echo match;; esac
f() { echo fn; }; f
echo one two three | cut -d' ' -f2
ls / | head -1
cat /dev/null | wc -c
export V=1; echo $V
echo ${PATH%%:*}
echo hi | tr h H
seq 3 | wc -l
(echo sub)
{ echo grp; }
echo a b c | while read x y z; do echo $y; done
echo "a b" | cut -d' ' -f1
x="q w"; echo $x
echo 'single $x'
# The sweep runs one line at a time, so a here-document spanning three lines became
# three separate commands - the body and the terminator were being executed as if they
# were programs. A single-line equivalent tests the same thing.
printf '%s\n' 'heredoc line'
echo a | { read v; echo $v; }
f() { local x=1; echo $x; }; f
f() { return 3; }; f; echo $?
echo {1..3}
echo /tm?
echo $((7/2))
echo $((-5+2))
test -f /etc/passwd && echo yes
test -d /etc && echo dir
i=0; until [ $i -ge 2 ]; do echo $i; i=$((i+1)); done
x=abc; echo ${#x}
x=abc; echo ${x%c}
x=abc; echo ${x#a}
(exit 5); echo $?
echo hi | tee /tmp/m3o | wc -l
printf 'aaa\n' > /tmp/m3in; grep a /tmp/m3in
printf 'aaa\n' > /tmp/m3in; grep -F a /tmp/m3in
printf 'aaa\n' > /tmp/m3in; sed s/a/A/ /tmp/m3in
yes | head -3
seq 1000 | head -2
seq 5 | tail -1
cat /tmp/m3in | wc -l
printf 'a 1 10\nb 2 20\na 3 30\n' > /tmp/m3aw; awk '{print $1}' /tmp/m3aw
printf 'a 1 10\nb 2 20\na 3 30\n' > /tmp/m3aw; awk 'END{print NR}' /tmp/m3aw
printf 'a 1 10\nb 2 20\na 3 30\n' > /tmp/m3aw; awk '$1 == "a" {print $2}' /tmp/m3aw
printf 'a 1 10\nb 2 20\na 3 30\n' > /tmp/m3aw; awk '{s += $3} END{print s}' /tmp/m3aw
printf 'a 1 10\nb 2 20\na 3 30\n' > /tmp/m3aw; awk 'BEGIN{print 1+2}'
printf 'aaa\nbbb\naaa\n' > /tmp/m3in; sed -n '2p' /tmp/m3in
printf 'aaa\nbbb\naaa\n' > /tmp/m3in; sed s/a/X/g /tmp/m3in
printf 'aaa\nbbb\naaa\n' > /tmp/m3in; grep -c a /tmp/m3in
printf 'aaa\nbbb\naaa\n' > /tmp/m3in; grep -v a /tmp/m3in
printf 'aaa\nbbb\naaa\n' > /tmp/m3in; grep -o b /tmp/m3in
expr abc : 'a.c'
EOF

# The BRE engine is fixed, so the sweep no longer excuses grep, sed or awk.
# Anything that fails now is a real failure.
# A list that produced almost nothing reports "0 passed, 0 failed", which reads like
# success. If the case list is ever emptied or mangled, say so instead.
if [ $((pass + fail)) -lt 50 ]; then
    echo "M3 sweep: only $((pass + fail)) case(s) ran, expected at least 50" >&2
    exit 1
fi
echo "M3 sweep: $pass passed, $fail failed"
if [ -n "$noisy" ]; then
    echo "  cases whose output mentions an error (may be intentional):"
    printf '%s\n' "$noisy"
fi
if [ "$fail" -ne 0 ]; then
    printf 'failures:%s\n' "$failed"
    exit 1
fi
